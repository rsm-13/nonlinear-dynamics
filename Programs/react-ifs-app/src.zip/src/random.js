export function random() {
    return Math.random();
}

export function randrange(max) {
    return Math.floor(Math.random() * max);
}